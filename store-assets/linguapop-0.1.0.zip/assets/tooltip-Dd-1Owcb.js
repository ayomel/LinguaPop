import{r as e}from"./encounters-BJd9WKxE.js";var t=`learningStatuses`;function n(e){return/^[a-z0-9]+(?:-[a-z0-9]+)*$/i.test(e)}function r(e){return e===`learned`||e===`practicing`}function i(e){if(typeof e!=`object`||!e||Array.isArray(e))return{};let t={};for(let[i,a]of Object.entries(e))n(i)&&r(a)&&(t[i]=a);return t}async function a(e=chrome.storage.local){return i((await e.get({[t]:{}}))[t])}var o=new WeakMap;function s(e,r,i=chrome.storage.local){if(!n(e))return Promise.reject(TypeError(`Invalid dictionary entry ID.`));let s=(o.get(i)??Promise.resolve()).then(async()=>{let n=await a(i);n[e]=r,await i.set({[t]:n})});return o.set(i,s.then(()=>void 0,()=>void 0)),s}var c=`[data-linguapop-replacement="true"]`;function l(e){if(!e||typeof e!=`object`||!(`nodeType`in e))return;let t=e;if(t.nodeType===1&&typeof t.closest==`function`)return t.closest(c)??void 0}function u(t=window.document,n=e,r={},i={}){let o=r.speechSynthesis===void 0?t.defaultView?.speechSynthesis:r.speechSynthesis??void 0,c=r.createUtterance??(e=>new SpeechSynthesisUtterance(e)),u,d,f=i.storage??(typeof chrome>`u`?void 0:chrome.storage.local),p=(e=!1)=>{if(u)try{o?.cancel()}catch{}let t=d;u?.remove(),u=void 0,d=void 0,e&&t?.focus()},m=e=>{let r=e.getAttribute(`data-linguapop-entry-id`),i=n.entries.find(e=>e.id===r),l=e.getAttribute(`data-linguapop-original`);if(!i||l===null)return;p();let m=t.createElement(`div`);m.setAttribute(`data-linguapop-ui`,`true`),m.setAttribute(`data-linguapop-tooltip`,`true`);let h=m.attachShadow({mode:`open`}),g=t.createElement(`style`),_=e.getBoundingClientRect(),v=t.defaultView,y=Math.max(8,Math.min(_.left,(v?.innerWidth??320)-288));g.textContent=`
      :host {
        all: initial;
        position: fixed;
        z-index: 2147483647;
        top: ${Math.max(8,Math.min(_.bottom+8,(v?.innerHeight??240)-140))}px;
        left: ${y}px;
        color: #17211b;
        font: 14px/1.4 system-ui, sans-serif;
      }
      .card {
        box-sizing: border-box;
        width: min(280px, calc(100vw - 16px));
        padding: 14px;
        border: 1px solid #c8d8cc;
        border-radius: 10px;
        background: #fff;
        box-shadow: 0 4px 18px #17211b33;
      }
      h2 { margin: 0 0 8px; color: #176b52; font-size: 16px; }
      p { margin: 6px 0; }
      .label { color: #536159; font-size: 12px; }
      .example { margin-top: 12px; padding-top: 8px; border-top: 1px solid #e3ebe5; }
      .example p { overflow-wrap: anywhere; }
      button {
        margin-top: 10px;
        padding: 5px 9px;
        border: 1px solid #176b52;
        border-radius: 5px;
        background: #f8fbf8;
        color: #176b52;
        font: inherit;
        cursor: pointer;
      }
      button:focus-visible { outline: 3px solid #7eb69f; outline-offset: 2px; }
      .learning-actions { display: flex; gap: 8px; flex-wrap: wrap; }
      .learning-actions button { margin-top: 4px; }
      .learning-actions button[aria-pressed="true"] { background: #176b52; color: #fff; }
    `;let b=t.createElement(`section`);b.className=`card`,b.setAttribute(`role`,`dialog`),b.setAttribute(`aria-label`,`${n.targetLanguage.name} translation for ${i.targetText}`);let x=t.createElement(`h2`);x.lang=n.targetLanguage.locale,x.textContent=i.targetText;let S=t.createElement(`p`),C=t.createElement(`span`);C.className=`label`,C.textContent=`${n.sourceLanguage.name} translation`;let w=t.createElement(`span`);if(w.textContent=l,S.append(C,t.createElement(`br`),w),b.append(x,S),i.pronunciation){let e=t.createElement(`p`);e.textContent=`Pronunciation: ${i.pronunciation}`,b.append(e)}if(i.exampleTargetText&&i.exampleSourceText||i.grammarNote){let e=t.createElement(`section`);if(e.className=`example`,i.exampleTargetText&&i.exampleSourceText){let r=t.createElement(`p`);r.className=`label`,r.textContent=`Example`;let a=t.createElement(`p`);a.lang=n.targetLanguage.locale,a.dataset.tooltipExample=`target`,a.textContent=i.exampleTargetText;let o=t.createElement(`p`);o.dataset.tooltipExample=`source`,o.textContent=i.exampleSourceText,e.append(r,a,o)}if(i.grammarNote){let n=t.createElement(`p`),r=t.createElement(`span`);r.className=`label`,r.textContent=`Grammar: `,n.dataset.tooltipExample=`grammar`,n.append(r,t.createTextNode(i.grammarNote)),e.append(n)}b.append(e)}let T=t.createElement(`button`);T.className=`speak`,T.type=`button`,T.textContent=`Speak ${n.targetLanguage.name}`;let E=t.createElement(`p`);E.setAttribute(`role`,`status`),E.setAttribute(`aria-live`,`polite`),o?T.addEventListener(`click`,()=>{try{let e=o.getVoices(),t=n.targetLanguage.speechLocale??n.targetLanguage.locale,r=e.find(e=>e.lang.toLowerCase()===t.toLowerCase())??e.find(e=>e.lang.toLowerCase().startsWith(`${n.targetLanguage.locale.toLowerCase()}-`));if(!r){E.textContent=`No ${n.targetLanguage.name} voice is available in this browser.`;return}o.cancel();let a=c(i.targetText);a.lang=t,a.voice=r,a.onerror=()=>{E.textContent=`Could not play the ${n.targetLanguage.name} pronunciation. Try again.`},E.textContent=`Speaking ${i.targetText}.`,o.speak(a)}catch{E.textContent=`Could not play the ${n.targetLanguage.name} pronunciation. Try again.`}}):(T.disabled=!0,E.textContent=`Speech synthesis is not available in this browser.`),b.append(T,E);let D=t.createElement(`p`);D.className=`label`,D.textContent=`Your learning status`;let O=t.createElement(`div`);O.className=`learning-actions`;let k=new Map;for(let[e,n]of[[`learned`,`Learned`],[`practicing`,`Practicing`]]){let r=t.createElement(`button`);r.type=`button`,r.textContent=n,r.dataset.learningStatus=e,r.setAttribute(`aria-pressed`,`false`),r.disabled=!f,k.set(e,r),O.append(r)}let A=t.createElement(`p`);A.setAttribute(`role`,`status`),A.setAttribute(`aria-live`,`polite`),A.dataset.learningStatusMessage=`true`,f||(A.textContent=`Learning status is not available in this context.`);let j=e=>{for(let[t,n]of k)n.setAttribute(`aria-pressed`,String(t===e))};for(let[e,t]of k)t.addEventListener(`click`,async()=>{if(f){for(let e of k.values())e.disabled=!0;A.textContent=`Saving learning status…`;try{await s(i.id,e,f),j(e),A.textContent=`Marked as ${e}.`}catch{A.textContent=`Could not save learning status. Try again.`}finally{for(let e of k.values())e.disabled=!1}}});b.append(D,O,A);let M=t.createElement(`button`);M.type=`button`,M.textContent=`Close translation`,M.addEventListener(`click`,()=>p(!0)),b.append(M),h.append(g,b),t.body.append(m),u=m,d=e,M.focus(),f&&a(f).then(e=>{if(u!==m)return;let t=e[i.id];j(t),A.textContent=t?`Currently ${t}.`:`Not marked yet.`}).catch(()=>{u===m&&(A.textContent=`Could not load learning status.`)})},h=e=>{let t=l(e.target);t?t!==d&&m(t):u&&!u.contains(e.target)&&!u.shadowRoot?.contains(e.target)&&p()},g=e=>{if(e.key===`Escape`&&u){e.preventDefault(),p(!0);return}let t=l(e.target);t&&(e.key===`Enter`||e.key===` `)&&(e.preventDefault(),m(t))};return t.addEventListener(`click`,h),t.addEventListener(`keydown`,g),{dispose(){t.removeEventListener(`click`,h),t.removeEventListener(`keydown`,g),p()}}}export{a as n,u as t};